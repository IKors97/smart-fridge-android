# Умный холодильник — Android Studio

Проект-обёртка Android WebView для исходного `index.html`. Интерфейс и логика взяты из загруженного HTML без намеренного редизайна.

## Что включено
- `app/src/main/assets/index.html` — исходное приложение;
- Android WebView с JavaScript и DOM Storage для `localStorage`;
- разрешение `INTERNET` для облачной синхронизации Supabase;
- ручной экспорт/импорт данных уже присутствует в HTML.

## Важные замечания проверки
1. HTML использует Tailwind через `https://cdn.tailwindcss.com`, шрифт Google Fonts и Supabase JS через jsDelivr. При отсутствии интернета Tailwind и шрифт могут не загрузиться, поэтому текущий HTML **пока не гарантирует полностью оформленный офлайн-интерфейс**. Для полноценного офлайна надо положить Tailwind CSS и Supabase JS локально в `assets` и заменить внешние ссылки. Основные данные сохраняются в `localStorage` WebView.
2. Облачная синхронизация не активируется сама: в интерфейсе нужно задать URL проекта Supabase, ключ и код комнаты. В проекте Supabase нужна таблица `public.household_sync` с полями `room_code` (text, unique), `products` (jsonb), `cart` (jsonb), `updated_at` (timestamptz), включённая Realtime-подписка и корректные RLS-политики. Используйте только ключ `anon`/publishable, никогда `service_role`. Текущая схема HTML не реализует аутентификацию пользователей.
3. Ручной перенос использует `navigator.clipboard`; поведение clipboard в локальном WebView может зависеть от версии Android/WebView. Проверьте на целевом устройстве; при необходимости замените на нативный Android share/clipboard bridge.
4. Проверена структура исходника и наличие функций localStorage/Supabase/export/import. Полноценный UI/эмуляторный тест здесь не выполнен.

## Сборка APK
Требуются Android Studio (актуальная стабильная версия), JDK 17 или новее, Android SDK Platform 35 и Build Tools. При первом открытии Android Studio скачает Gradle/плагины — нужен интернет.

1. Откройте папку `SmartFridge` в Android Studio.
2. Дождитесь Gradle Sync и установите SDK Platform 35, если IDE предложит.
3. Для теста: **Run** на подключённом Android-устройстве или эмуляторе.
4. APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Обычный debug APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

CLI после установки Android SDK/Gradle: `gradle assembleDebug` из корня проекта. Для публикации нужен отдельный подписанный release APK.

## Минимальная проверка перед использованием
- включить авиарежим и проверить запуск, сохранение/перезапуск и навигацию;
- включить сеть и проверить Supabase на двух устройствах;
- экспортировать данные, импортировать на втором устройстве;
- проверить ввод текста, клавиатуру, поворот экрана и поведение системной кнопки «Назад».
